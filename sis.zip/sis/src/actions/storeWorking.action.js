import { TYPE_TOGGLE } from './actionTypes'

export const toggleStoreWorkingAction = () => (dispatch) => dispatch({ type: TYPE_TOGGLE })
