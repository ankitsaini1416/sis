import React from 'react'

const RouteContext = React.createContext()

export default RouteContext
