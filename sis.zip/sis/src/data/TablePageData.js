export const TablePageData = {
  current_page: 1,
  from: 1,
  last_page: 1,
  per_page: 10,
  to: 0,
  total: 0,
  query: '',
  per_page_options: [5, 10, 25, 50, 75, 100, 200],
}
